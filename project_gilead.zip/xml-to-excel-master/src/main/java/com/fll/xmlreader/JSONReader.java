package com.fll.xmlreader;

public interface JSONReader {

}
