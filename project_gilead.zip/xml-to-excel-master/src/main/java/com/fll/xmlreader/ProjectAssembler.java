package com.fll.xmlreader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

public class ProjectAssembler {

	public static void main(String[] args) throws ParseException {

		Gson gson = new Gson();
		JsonReader reader = null;
		try {
			reader = new JsonReader(new FileReader(
					"C:\\Users\\002YYU744\\eclipse-workspace\\xml-to-excel-master.zip_expanded\\xml-to-excel-master\\src\\main\\java\\com\\fll\\xmlreader\\projectsetup.json"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Node input = gson.fromJson(reader, Node.class);
		if (!input.getNodeList().isEmpty()) {
			List<Node> firstLevel = new ArrayList<Node>();
			firstLevel.addAll(getResolvedNodes(input));
			createDirectory(input);
			List<Node> thirdLevel = new ArrayList<Node>();
			for (Node node : firstLevel) {
				List<Node> secondLevel = new ArrayList<Node>();
				secondLevel.addAll(getResolvedNodes(node));
				createDirectory(node);
				if (!secondLevel.isEmpty()) {
					for (Node node2 : secondLevel) {
						thirdLevel.addAll(getResolvedNodes(node2));
						createDirectory(node2);
					}
				}

			}
			for (Node node3 : thirdLevel) {
				createDirectory(node3);
				if (node3.getNodeList() != null) {
					for (int i = 0; i < (node3.getNodeList().size()); i++) {
						System.out.println(node3.getNodeList().get(i).getName());
						createDirectory(node3.getNodeList().get(i));
					}

				}
			}
		}
	}

	private static List<Node> getResolvedNodes(Node input) {
		List<Node> resolvedNodes = new ArrayList<Node>();
		for (Node node : input.getNodeList()) {
			resolvedNodes.add(node);
		}
		return resolvedNodes;
	}

	private static void createDirectory(Node node) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("C:\\Users\\002YYU744\\");
		strBuilder.append(node.getName());
		File file = new File(strBuilder.toString());
		boolean isDirectoryCreated = file.mkdir();
		if (isDirectoryCreated)
			System.out.println("Directory  " + strBuilder.toString() + " created!!");
		else
			System.out.println("Already Created!!");
	}
}
