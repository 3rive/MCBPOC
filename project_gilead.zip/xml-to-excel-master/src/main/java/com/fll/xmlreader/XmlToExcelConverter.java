package com.fll.xmlreader;

import java.io.File;
import java.io.FileOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author 002YYU744
 *
 */
public class XmlToExcelConverter {
    private static Workbook workbook;
    private static int rowNum;

    private final static int ZERO = 0;
    private final static int ONE = 1;
    private final static int TWO = 2;
    private final static int THREE = 3;



    public static void main(String[] args) throws Exception {
        getAndReadXml();
    }


    /**
     *
     * Downloads a XML file, reads the substance and product values and then writes them to rows on an excel file.
     *
     * @throws Exception
     */
    private static void getAndReadXml() throws Exception {
    	System.out.println("Starting the process....");
        File xmlFiletoProcess = new File("C:\\Users\\002YYU744\\Desktop\\EDMAPI_METADATA.xml");

        initXls();

        Sheet sheet = workbook.getSheetAt(0);

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFiletoProcess);

        NodeList nList = doc.getElementsByTagName("Property");
        for (int i = 0; i < nList.getLength(); i++) {
            Node node = nList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                String name = element.getAttribute("Name");
                String dataType = element.getAttribute("Type");
                String datalabel = element.getAttribute("sap:label");
                String datalength = element.getAttribute("MaxLength");


                        Row row = sheet.createRow(rowNum++);
                        Cell cell = row.createCell(ZERO);
                        cell.setCellValue(name);

                        cell = row.createCell(ONE);
                        cell.setCellValue(dataType);

                        cell = row.createCell(TWO);
                        cell.setCellValue(datalabel);

                        cell = row.createCell(THREE);
                        cell.setCellValue(datalength);
            }
        }


        FileOutputStream fileOut = new FileOutputStream("C:/Temp/Excel-Out.xlsx");
        workbook.write(fileOut);
        workbook.close();
        fileOut.close();
        System.out.println("Ending the process....");
        System.out.println("getAndReadXml finished, processed " + nList.getLength() + " substances!");
    }


    /**
     * Initializes the POI workbook and writes the header row
     */
    private static void initXls() {
        workbook = new XSSFWorkbook();

        CellStyle style = workbook.createCellStyle();
        Font boldFont = workbook.createFont();
        boldFont.setBold(true);
        style.setFont(boldFont);
        style.setAlignment(CellStyle.ALIGN_CENTER);

        Sheet sheet = workbook.createSheet();
        rowNum = 0;
        Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(ZERO);
        cell.setCellValue("Property Name");
        cell.setCellStyle(style);

        cell = row.createCell(ONE);
        cell.setCellValue("DataType");
        cell.setCellStyle(style);

        cell = row.createCell(TWO);
        cell.setCellValue("Data Label");
        cell.setCellStyle(style);

        cell = row.createCell(THREE);
        cell.setCellValue("Max Length");
        cell.setCellStyle(style);

    }
}
