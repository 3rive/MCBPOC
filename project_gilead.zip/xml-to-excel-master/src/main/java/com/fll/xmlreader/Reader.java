/**
 * 
 */
package com.fll.xmlreader;

/**
 * @author 002YYU744
 *
 */
public interface Reader {

}
